// ---------- static content ----------
const C={g:'#3e8d40',y:'#e7c756',r:'#e05346'};
const $=id=>document.getElementById(id);
const PROFS=[['Matthew Butner','4.7','g','B'],['Zhaojun Bai','3.5','y','Z'],['Yelena Frid','1.9','r','F']];
$('profs').innerHTML=PROFS.map(p=>`<div class="prof"><div class="pb" style="background:${C[p[2]]}">${p[1]}</div><div class="pinfo"><div class="nm">${p[0]}</div><div class="ptags"><span>Tough Grader</span><span>Attendance Mandatory</span></div></div><div class="pact"><div class="ib"><img src="../assets/prof_add.svg" width="24"></div><div class="ib"><img src="../assets/prof_bm.svg" width="24"></div></div></div>`).join('');
$('revF').innerHTML=`<div class="rh"><div class="rb" style="background:#e05346">2.0</div><div class="rn"><b>Yelena Frid</b><span>Statistics</span></div><div class="pact"><img src="../assets/add.svg" width="24"><img src="../assets/bookmark.svg" width="24"><img src="../assets/chev_up.svg" width="24"></div></div><div class="rtags"><span>Tough Grader</span><span>Attendance Mandatory</span><span>Clear Grading</span></div>`;
$('revF').style.opacity=1;$('rempty').style.display='none';$('rbody').style.height='120px';
$('gempty').style.display='none';$('tempty').style.display='none';
$('gbody').style.height='268px';$('tbody').style.height='268px';
$('gtip').style.display='none';

const KEYS=['P','T','Z'];
const SER={P:{name:'Y. Frid',dot:'#7C3AED',bg:'#F3EEFF',avg:'3.2'},T:{name:'M. Butner',dot:'#6AC2A9',bg:'#EFF8F8',avg:'3.2'},Z:{name:'Z. Bai',dot:'#F59E0B',bg:'#FFF5E1',avg:'3.5'}};
function chipHTML(k,pre){const s=SER[k];return `<div class="chip" id="${pre}${k}" style="background:${s.bg};margin-right:12px"><div class="n"><i style="background:${s.dot}"></i>${s.name}<div class="x"><svg width="10" height="10" viewBox="0 0 10 10" stroke="currentColor" stroke-width="1.6" stroke-linecap="round"><path d="M2 2l6 6M8 2 2 8"/></svg></div></div><div class="v">${s.avg}<span>AVG GPA</span></div></div>`}
for(const pre of ['g','t'])$(pre+'legend').innerHTML=`<div style="display:flex;align-items:center">${KEYS.map(k=>chipHTML(k,pre)).join('')}</div>`;

const PW=608,PH=160,NS='http://www.w3.org/2000/svg';
const GR=['A+','A','A-','B+','B','B-','C+','C','C-','D+','D','D-','F'];
const H={P:[13,56,32,13,8,5,2,2,2,2,2,2,2],T:[16,72,24,8,5,3,2,2,2,2,2,2,2],Z:[22,46,40,22,13,7,4,3,2,2,2,2,2]};
const gcx=i=>25+i*(PW-50)/12;
function mk(tag,attrs,parent){const e=document.createElementNS(NS,tag);for(const k in attrs)e.setAttribute(k,attrs[k]);parent&&parent.appendChild(e);return e}
for(const id of ['gsvg','tsvg']){const s=$(id);for(let i=0;i<5;i++)mk('line',{x1:0,x2:PW,y1:i*40+.5,y2:i*40+.5,stroke:i==4?'#d9d9d9':'#EFEFEF','stroke-width':1},s)}
$('gx').innerHTML=GR.map((g,i)=>`<span style="left:${gcx(i)}px">${g}</span>`).join('');
const gs=$('gsvg');const bars={};
for(const k of KEYS){bars[k]=[];for(let i=0;i<13;i++)bars[k].push(mk('rect',{width:8,rx:2,fill:SER[k].dot},gs))}
const QS=['FQ24','WQ25','SQ25','FQ25'];const tcx=i=>25+i*(PW-50)/3;
$('tx').innerHTML=QS.map((g,i)=>`<span style="left:${tcx(i)}px">${g}</span>`).join('');
const V={P:[3.4,3.0,3.3,2.9],T:[2.8,3.2,3.0,3.6],Z:[3.5,3.7,3.4,3.8]};
const ts=$('tsvg');
function mkLine(v,col){const pts=v.map((x,i)=>[tcx(i),PH-x/4*PH]);const p=mk('path',{d:'M'+pts.map(p=>p.join(',')).join(' L'),fill:'none',stroke:col,'stroke-width':2,'stroke-linejoin':'round','stroke-linecap':'round'},ts);const L=p.getTotalLength();p.setAttribute('stroke-dasharray',L);const dots=pts.map(q=>mk('circle',{cx:q[0],cy:q[1],r:3.5,fill:'#fff',stroke:col,'stroke-width':2},ts));const segL=[0];for(let i=1;i<pts.length;i++)segL.push(segL[i-1]+Math.hypot(pts[i][0]-pts[i-1][0],pts[i][1]-pts[i-1][1]));return {p,L,dots,segL}}
const lines={};for(const k of KEYS)lines[k]=mkLine(V[k],SER[k].dot);

// ---------- helpers ----------
const cl=x=>x<0?0:x>1?1:x, seg=(t,a,b)=>cl((t-a)/(b-a));
const io=x=>x<.5?4*x*x*x:1-Math.pow(-2*x+2,3)/2, oc=x=>1-Math.pow(1-x,3), oq=x=>1-Math.pow(1-x,4);
const ob=x=>{const c1=1.3,c3=c1+1;return 1+c3*Math.pow(x-1,3)+c1*Math.pow(x-1,2)};
const lerp=(a,b,x)=>a+(b-a)*x;

// ---------- timeline ----------
const END=11.6, M=3.5;           // M = morph start
const ADD={P:4.7,T:4.95,Z:5.2};  // series reveal
const HL=[['P',6.1,7.0],['T',7.15,8.05],['Z',8.2,9.1]];
const SCROLL=420;
const FULL={s:1,x:720,y:394};
const CAM=[[0,{s:.97,x:720,y:400}],[.7,FULL],[1.9,{s:1.12,x:800,y:400}],[2.6,{s:1.5,x:1010,y:340}],[3.05,{s:1.52,x:1010,y:340}],[3.6,FULL],[4.6,FULL],[5.7,{s:1.42,x:560,y:430}],[9.2,{s:1.47,x:560,y:430}],[10.4,FULL],[END,FULL]];
function cam(t){let i=0;while(i<CAM.length-1&&CAM[i+1][0]<=t)i++;if(i>=CAM.length-1)return CAM[CAM.length-1][1];const [t0,a]=CAM[i],[t1,b]=CAM[i+1];const x=io(seg(t,t0,t1));return {s:Math.exp(lerp(Math.log(a.s),Math.log(b.s),x)),x:lerp(a.x,b.x,x),y:lerp(a.y,b.y,x)}}

function render(t){
  const intro=oq(seg(t,0,.7));
  $('win').style.opacity=intro;
  const c=cam(t);
  const fx=240+c.x, fy=146+c.y;
  $('world').style.transform=`translate(960px,540px) scale(${c.s}) translate(${-fx}px,${-fy+(1-intro)*30}px)`;
  // --- old page + spotlight ---
  const sp=oc(seg(t,2.05,2.35))*(1-oc(seg(t,3.0,3.3)));
  $('spot').style.opacity=sp;
  const pulse=seg(t,2.3,3.0);const rs=1+.14*oc(pulse);
  $('spotRing').style.opacity=sp*(1-pulse)*.9;$('spotRing').style.transform=`scale(${rs})`;
  // morph: filter + list slide out, detail column glides left and dissolves into the new page
  const f1=io(seg(t,M,M+.5)), f2=io(seg(t,M+.05,M+.6)), f3=io(seg(t,M+.1,M+.85));
  $('oF').style.transform=`translateX(${-80*f1}px)`;$('oF').style.opacity=1-f1;
  $('oL').style.transform=`translateX(${-160*f2}px)`;$('oL').style.opacity=1-f2;
  $('oD').style.transform=`translateX(${-(640-180)*f3}px)`;$('oD').style.opacity=1-oc(seg(t,M+.45,M+.85));
  $('oH').style.opacity=1-oc(seg(t,M+.3,M+.7));
  $('old').style.background=`rgba(242,242,242,${1-oc(seg(t,M+.3,M+.8))})`;
  $('old').style.opacity=t>M+1?0:1;
  // --- new page ---
  $('page').style.opacity=oc(seg(t,M+.4,M+.8));
  const st=[...document.querySelectorAll('#page .st')];
  st.forEach((el,i)=>{const p=oq(seg(t,M+.45+i*.05,M+1.0+i*.05));el.style.opacity=p;el.style.transform=`translateY(${(1-p)*16}px)`});
  $('scroll').style.transform=`translateY(${-SCROLL*io(seg(t,4.55,5.6))}px)`;
  // highlight weights: dim[k] = how much series k is pushed back
  const dim={P:0,T:0,Z:0}, act={P:0,T:0,Z:0};
  for(const [k,a,b] of HL){const f=io(seg(t,a,a+.22))*(1-io(seg(t,b,b+.22)));for(const j of KEYS){if(j===k)act[j]=Math.max(act[j],f);else dim[j]=Math.max(dim[j],f)}}
  for(const k of KEYS)dim[k]=dim[k]*(1-act[k]);
  // chips
  for(const pre of ['g','t'])for(const k of KEYS){
    const fin=seg(t,ADD[k]+.05,ADD[k]+.5);const el=$(pre+k);
    el.style.opacity=cl(fin*2)*(1-.6*dim[k]);
    el.style.transform=`translateY(${-2*act[k]}px) scale(${.85+.15*ob(fin)})`;el.style.transformOrigin='left center';
    el.style.boxShadow=`0 0 0 ${1.5*act[k]}px ${SER[k].dot}, 0 ${6*act[k]}px ${14*act[k]}px rgba(16,24,40,${.10*act[k]})`;
  }
  for(const pre of ['g','t'])$(pre+'chart').style.opacity=oc(seg(t,ADD.P,ADD.P+.4));
  // bars: three-up groups, 8px bars, 2px gaps
  for(let i=0;i<13;i++){const cx=gcx(i);
    KEYS.forEach((k,j)=>{const g=oq(seg(t,ADD[k]+.15+i*.03,ADD[k]+.8+i*.03));const h=H[k][i]*g;const r=bars[k][i];
      r.setAttribute('x',cx-14+j*10);r.setAttribute('y',PH-h);r.setAttribute('height',Math.max(0,h));r.style.opacity=h>.2?(1-.82*dim[k]):0})}
  // lines
  for(const k of KEYS){const L=lines[k];const prog=io(seg(t,ADD[k]+.25,ADD[k]+1.15));const fade=1-.85*dim[k];
    L.p.setAttribute('stroke-dashoffset',L.L*(1-prog));L.p.style.opacity=fade;L.p.setAttribute('stroke-width',2+1*act[k]);
    if(act[k]>0){L.p.parentNode.appendChild(L.p);L.dots.forEach(d=>L.p.parentNode.appendChild(d))}
    const d=prog*L.L;L.dots.forEach((dt,i)=>{const kk=oc(cl((d-L.segL[i])/30+1));dt.setAttribute('r',(3.5+1*act[k])*ob(cl(kk)));dt.style.opacity=(prog>0&&d>=L.segL[i]-1?1:0)*fade})}
  $('cursor').style.opacity=0;$('ripple').style.opacity=0;
}
window.render=render;window.DUR=END;
window.ready=document.fonts.ready.then(()=>{render(0);return true});
if(location.hash==='#play'){window.ready.then(()=>{const t0=performance.now();(function f(){render(((performance.now()-t0)/1000)%END);requestAnimationFrame(f)})()})}

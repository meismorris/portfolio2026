// Render a scene to MP4: node render.js scenes/01-grades-on-course-page.html [out.mp4] [--fps 60] [--scale 1]
// Still frame:          node render.js scenes/01-grades-on-course-page.html --still 7.5
const {chromium}=require('playwright');const {spawn}=require('child_process');const path=require('path');
const args=process.argv.slice(2);const opt=k=>{const i=args.indexOf(k);return i>=0?args[i+1]:null};
const scene=args[0];if(!scene){console.log('usage: node render.js scenes/<scene>.html [out.mp4] [--fps 60] [--scale 1] [--still t]');process.exit(1)}
const fps=+(opt('--fps')||60), scale=+(opt('--scale')||1), still=opt('--still');
const out=(args[1]&&!args[1].startsWith('--'))?args[1]:path.join('out',path.basename(scene,'.html')+(still?`@${still}s.png`:'.mp4'));
(async()=>{
  const b=await chromium.launch();const p=await b.newPage({viewport:{width:1920,height:1080},deviceScaleFactor:scale});
  p.on('pageerror',e=>console.error('page error:',e.message));
  await p.goto('file://'+path.resolve(scene));await p.evaluate(()=>window.ready);
  if(still){await p.evaluate(t=>render(t),+still);await p.screenshot({path:out});console.log('wrote',out);return b.close()}
  const dur=await p.evaluate(()=>window.DUR);const N=Math.round(dur*fps);
  const ff=spawn('ffmpeg',['-y','-v','error','-f','image2pipe','-framerate',String(fps),'-i','-',
    ...(scale!==1?['-vf',`scale=${1920*scale}:${1080*scale}:flags=lanczos`]:[]),
    '-c:v','libx264','-preset','slow','-crf','14','-pix_fmt','yuv420p','-movflags','+faststart',out]);
  for(let i=0;i<N;i++){await p.evaluate(t=>render(t),i/fps);const buf=await p.screenshot({type:'png'});
    if(!ff.stdin.write(buf))await new Promise(r=>ff.stdin.once('drain',r));
    if(i%60===0)process.stdout.write(`\r${scene}: ${i}/${N} frames`)}
  ff.stdin.end();await new Promise(r=>ff.on('close',r));await b.close();console.log(`\nwrote ${out} (${dur}s @ ${fps}fps)`);
})();

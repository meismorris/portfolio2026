# Cattlelog prototype videos
Open this folder in Claude Code — `CLAUDE.md` has everything it needs.
Finished videos: `out/`. Re-render: `npm install && npx playwright install chromium && npm run render:all` (needs ffmpeg).
Preview in a browser: `npm run preview` → http://localhost:8080/scenes/01-grades-on-course-page.html#play

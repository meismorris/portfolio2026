# Cattlelog prototype videos

Three coded motion prototypes for the **Solution** section of the Cattlelog UX case study
(Cattlelog = UC Davis course-planning site). Each scene is a single HTML page whose whole
state is a pure function of time `t`, so every frame is deterministic and renders to MP4.

## Scenes
| File | Length | Story |
|---|---|---|
| `scenes/01-grades-on-course-page.html` | 15s | Search "CDM 003" → open course → grade cards already on the page (empty state) → search & add Y. Frid, then M. Butner → hover "A" bar tooltip → remove Frid via chip "x" |
| `scenes/02-layout-and-compare.html` (+ `.js`) | 11.6s | Old 3-column page (screenshot `assets/old.png`) → spotlight on "View Grade Distributions" → columns reflow into new course page → 3 professors overlay → each professor highlighted across both charts. No cursor. |
| `scenes/03-empty-search.html` | 7.2s | Search "CDM 999" → "Looks like an empty pasture..." empty state → "Clear Search" → list restores |

Rendered MP4s are in `out/`.

## Commands
- `npm install && npx playwright install chromium` (once; also needs `ffmpeg` on PATH)
- `npm run render:all` — re-render every MP4 into `out/` (1920×1080, 60fps)
- `node render.js scenes/<file>.html --still 7.5` — PNG of one moment (fast way to check a change)
- `node render.js scenes/<file>.html out/x.mp4 --scale 2` — supersampled for extra crispness
- Live preview: `npm run preview`, open `http://localhost:8080/scenes/<file>.html#play` (loops in real time)

## How a scene works
- Stage is 1920×1080. `#world` is the camera; `#win` is the floating browser window holding the app
  (app is laid out at Figma's 1440px width).
- `render(t)` sets every style from `t`. Never use CSS transitions/animations — they break frame capture.
- Helpers: `seg(t,a,b)` → 0..1 progress; easings `io` (in-out cubic), `oc`/`oq` (out cubic/quart), `ob` (gentle overshoot).
- **Timing** lives in constants near `// ---------- timeline ----------` (`T`, `F`, `B`, `R`, `CK*`, `END`, …).
  To speed up/slow down, change those plus the matching `CAM` keyframes and `cursorPath` segments.
- **Camera**: `CAM = [[time,{s:zoom,x,y}],…]` — x/y are app-pixel coordinates to center on; zoom interpolates in log space.
- **Cursor**: `cursorPath(t)` moves between targets in `TG`, which are measured from real DOM elements in
  `measure()` / `window.ready` — if you move a UI element, the cursor follows automatically.
- `window.DUR` = scene length; `window.ready` resolves after fonts load and targets are measured.

## Design source
Figma file `OmcL296OeqZ4xsHzNcap65` ("Cattlelog"): course list 10969:10139, filtered list 11588:17181,
course page empty 11588:19030, one professor 11588:19621, two professors 11594:15639, empty pasture 10845:19526.
Tokens: navy #164263, page bg #F9FAFB, text #181818, border #D9D9D9, rating green #3E8D40 / yellow #E7C756 / red #E05346.
Series colors: Frid #7C3AED on #F3EEFF, Butner #6AC2A9 on #EFF8F8, Bai #F59E0B on #FFF5E1. Font: Figtree (bundled in assets/fonts).

## Not from Figma (added for the videos)
Professor search dropdown (scene 1), "x" on legend chips, chart hover column + tooltip shadow, Z. Bai's color & data,
highlight/dim effect (scene 2), navy hover on the empty-state button and search-specific empty-state copy (scene 3).
GPA trend values and M. Butner's department are placeholders.

## Style rules from the designer
Clean light UI, navy/white with soft purple/teal; smooth natural cursor, gentle easing, no flashy transitions;
no voiceover, music, or text overlays; don't add features beyond the design without asking.

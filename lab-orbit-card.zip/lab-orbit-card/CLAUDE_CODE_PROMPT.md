# Lab Search Orbit Card – Claude Code handoff

1. Unzip this folder into the root of your portfolio project (so `lab-orbit-card/` sits next to your other project files).
2. Open the project in VS Code, start Claude Code, and paste the prompt below.

---

```
In lab-orbit-card/ there's lab-orbit-card.html: a finished, working animated stat card
(GSAP 3.12.5) for my FindMyLab case study. Port it into my portfolio site.

Requirements:
- Recreate it as a component that matches how this project is built (framework, file
  structure, styling approach). Keep the markup, CSS, icon SVGs and all GSAP/orbit logic
  exactly the same — don't redesign or retime anything.
- Install GSAP from npm (gsap@3.12.5) if this project uses a bundler; otherwise keep the
  CDN script tag.
- Keep the sizing system: the card uses `container-type: inline-size` and
  `--u = 100cqw / 1002` so everything scales from a 1002×340 frame. Don't swap it for
  fixed px.
- Load Manrope 700 the same way the rest of the site loads fonts.
- Keep ICON_COUNT as a prop (default 10; 6 and 8 also supported).
- The wrench icon uses an SVG <mask id="wrench-cut">. If the component can render more
  than once on a page, make that id unique per instance (e.g. React useId).
- Behavior to preserve:
  1. The text is centered on two lines; icon tiles orbit it slowly on an oval, spaced
     evenly by arc length so the gaps stay equal all the way around.
  2. Tiles get slightly bigger at the front (bottom) and smaller at the back (top).
  3. Moving the mouse near a tile gently pushes it away and tints its glow; hovering the
     card slows the orbit; hovering a tile lifts it with a small tilt.
  4. The orbit pauses while the card is off screen.
  5. With prefers-reduced-motion, show the tiles in fixed positions with no motion.
- If it's React/Next, set up the animation inside useGSAP or a useEffect with a
  gsap.context(), and on unmount remove the gsap.ticker callback, the IntersectionObserver,
  and the resize/pointer listeners so it doesn't double-run in dev Strict Mode.
- Remove the demo page wrapper (the gray stage background and body padding); the card
  should just fill the width of wherever I place it.
- Put it in my FindMyLab case study where the "90% struggled with finding labs" stat
  goes (ask me if unsure), then delete the lab-orbit-card/ folder once it's working.
```

Notes
- Tiles 7–10 (book, lightbulb, chart, flask) are placeholder icons. Swap their SVGs when you have real ones.
- The card is 340 tall (the original Figma frame was 260).

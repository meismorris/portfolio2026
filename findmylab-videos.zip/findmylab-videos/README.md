# FindMyLab demo videos

Two product demo clips for the FindMyLab case study. No background or frame is baked in, so your site supplies the background.

| File | Length | What it shows |
|---|---|---|
| `videos/findmylab-demo.mp4` / `.webm` | 23.0 s | Help guide (4 steps) → filter by department → browse cards → click a research tag → open a lab → bookmark → contact email template |
| `videos/findmylab-questionnaire.mp4` / `.webm` | 9.9 s | Questionnaire concept: interests → passions → impact → "You're done" → persona + matched labs. Has a "Concept, not shipped" label. The last frame matches the first, so it loops seamlessly. |

Specs: 1440×900 (16:10), 60 fps, no audio. MP4 is H.264 with faststart; WebM is VP9 (slightly smaller). Posters in `posters/` are each video's first frame.

## Where to put it

Copy the `videos/` and `posters/` folders into your site's static or public folder, for example:

- Next.js / Vite / Astro: `public/videos/…` and `public/posters/…` (served from `/videos/…`)
- Plain HTML: next to your `index.html`

## Embed snippet

```html
<video
  class="case-video"
  autoplay muted loop playsinline
  preload="metadata"
  poster="/posters/findmylab-demo.jpg"
  width="1440" height="900"
  aria-label="FindMyLab demo: guide, filtering, tags, lab details, bookmark and contact">
  <source src="/videos/findmylab-demo.webm" type="video/webm">
  <source src="/videos/findmylab-demo.mp4" type="video/mp4">
</video>

<video
  class="case-video"
  autoplay muted loop playsinline
  preload="metadata"
  poster="/posters/findmylab-questionnaire.jpg"
  width="1440" height="900"
  aria-label="FindMyLab questionnaire concept: three steps to a research persona and matched labs">
  <source src="/videos/findmylab-questionnaire.webm" type="video/webm">
  <source src="/videos/findmylab-questionnaire.mp4" type="video/mp4">
</video>
```

```css
.case-video {
  display: block;
  width: 100%;
  max-width: 1087px;      /* the size used in the case-study layout */
  height: auto;
  aspect-ratio: 16 / 10;
  border-radius: 14px;    /* optional: the videos have square corners */
  margin-inline: auto;
}
```

Autoplay only works when the video is `muted` and has `playsinline`. Both are needed for iOS Safari.

## Prompt to paste into Claude Code

> Add the two FindMyLab demo videos to the case study page. The files are in `findmylab-videos/` (videos in `videos/`, first-frame posters in `posters/`). Move them into the project's public/static folder, then embed each as a muted, looping, autoplaying `<video>` with `playsinline`, `preload="metadata"`, the matching poster, a WebM source first and an MP4 fallback. Size them to fill the content column up to about 1087px wide at a 16:10 aspect ratio, with rounded corners to match the site. Put the main demo first and the questionnaire concept clip second, using the descriptions in `findmylab-videos/README.md` for captions and aria-labels. Pause both videos when `prefers-reduced-motion: reduce` is set and show the poster instead.

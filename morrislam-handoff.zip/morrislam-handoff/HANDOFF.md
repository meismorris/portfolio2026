# morrislam.me — scribble + gradient handoff

Design changes worked out with Claude, to be applied to the `meismorris/portfolio2026` repo
(Framer export + React islands, served from `public/`). Everything here is finished design;
your job is to land it in the real site faithfully, without changing anything else.

**Work on a new branch. Don't push to `main` or deploy without asking Morris.**

---

## What's in this folder

```
HANDOFF.md                     this file
PROMPT.md                      the prompt Morris pastes into Claude Code
hero/
  scribble-defs.svg.html       hidden <svg> with 4 stroke gradients + 2 grain filters (ids below)
  hero-scribbles.css           gradients + grain on the existing hero scribbles, extras placement, draw-on
  hero-extras.html             the 7 new pieces (Light A): 3 stars + 4 dots, ready-made SVG markup
  hero-extras-boil.js          star "boil" animation (200ms frame swap, like the rays)
  extras-layout.json           the same 7 pieces as data (offset from headline centre, size, rotation, gradient)
cards/
  cards-gradients.css          FindMyLab + Cattlelog panel overrides, append to public/hero-animation.css
assets/figma-projects/...      new images → copy into public/figma-projects/ (same sub-paths)
reference/
  hero/index.html              standalone working hero (open in a browser; Light A is the default)
  cards/index.html             standalone working Selected Projects section (needs a local server)
  screenshots/*.png            what "done" looks like
tools/
  mesh.py, variants.json,      regenerates the gradient images (python3 + numpy + scipy + pillow)
  cl_twilight.json
```

Run the references with `python3 -m http.server` inside `reference/cards` (it loads relative files).
`reference/hero/index.html` opens directly. In it, the bottom switcher (A / B / C / no extras) is a
design-review tool only. **Ship Light A, no switcher.**

---

## Design decisions (the "why", so you can judge edge cases)

**Hero scribbles**
- Each scribble keeps its **original colour family**; the gradient only shifts *within* it:
  - rays → `g-sky` (blue → sky → a touch of mint at the tips)
  - stem → `g-lime` (lime only, `#B7D45A → #D2EC5C`)
  - flower + its centre circle → `g-warm` (cream-peach → orange `#FF6835`)
  - underline → `g-ribbon` (periwinkle `#B3BCFF` mixed with sky blue `#86BDFC`; no lime/peach)
- Film grain inside the strokes via SVG filter `#grain`. The **flower uses `#grain-soft`**: lower contrast, ~half strength.
- New extras = **Light A only**: 3 stars (blue `g-sky`, periwinkle `g-ribbon`, orange `g-warm`) + 4 dots
  (lime, orange, blue, lime). Spread evenly around the headline, at least about 105px in from the
  viewport edges at 1440px, never overlapping the headline, rays, stem/flower or underline.
- Motion: extras **draw on once** (`pathLength=1` dash, 0.9s, staggered), then **no floating**.
  **Stars boil** (3 hand-drawn frames swapped every 200ms, no tween), the same rhythm as the existing
  rays component. Dots stay still. Respect `prefers-reduced-motion` (no draw, no boil).

**Selected Projects cards**
- **FindMyLab panel**: background is the **"Drift"** flow-mesh image (`mesh-drift.webp`) instead of flat `#8ec4ff`.
  The two Figma wave SVGs stay but are re-filled via CSS `mask` with Drift-matched gradients and blurred.
  Doodles (magnifier, books, flask, microscope) become **deep blue `rgba(52,86,206,.5)`** line art for legibility.
  A light grain overlay (`::before` noise + `::after` specks) sits **above** background/waves/doodles but
  **below** the screenshot, search bar, stat chips and team photo (z-index layering in the CSS).
- **Cattlelog panel**: background is **"Twilight"** (`mesh-twilight.webp`), the deep end of the same blues,
  replacing the navy silk `gradient.webp` (hidden with `visibility:hidden`). Vignette re-tinted from
  navy-black to deep cobalt. Stars, plane trail, logo and floating cards unchanged.
- Both panels' **GSAP hover animations must keep working exactly as before** (typing, counters, photo
  slide-in, parallax, star twinkle, plane flight).
- Palette: `#7398F4 #78B0FF #86C2FC #A2C3FA #B3BCFF #C6E2FB` (Drift),
  `#24358E #2F46B4 #3C5BCF #4E72E0 #6F90F0 #93B0F6` (Twilight).

---

## Where things live in the repo

| Piece | Source | Notes |
|---|---|---|
| Rays (top-left) | `src/framer/Ximws3R4.js` | 3 variants, each a **data-URI background-image SVG**, stroke `rgb(173, 214, 247)`, cycled every 200ms. Mounted into `.framer-1xaff57-container` by `src/hero-animation.jsx`. |
| Stem / Flower / centre circle | `src/framer/N7n53oxvv.js` | inline SVGs, containers `.framer-jtt07z-container` (stem), `.framer-1jnut3u-container` (flower), `.framer-1s6qdzm-container` (circle). Mounted into `.framer-a9p31y-container`. |
| Underline | Framer "Animate" in `public/index.html`, container `.framer-vb22b2-container` | colour forced in `public/hero-animation.css` (~line 89: `stroke: #BFC8F5 !important`). |
| Hero container | `.framer-XFJ9q .framer-wmjcqf` (`position: relative`, 578px tall at desktop) | put `.hero-extras` here. |
| Cards | `src/SelectedProjects.jsx`, `src/CattlelogPanel.jsx`, styles in `public/hero-animation.css` | bundle built by `npm run build` (`scripts/build-hero.mjs`) → `public/hero-animation.js` + cache-busted tags in `public/index.html`. |

---

## Steps

1. **Branch**: `git checkout -b scribbles-and-gradients`.
2. **Defs**: insert `hero/scribble-defs.svg.html` **as the first child of `<body>`** so the ids
   `g-sky g-lime g-warm g-ribbon grain grain-soft` exist. ⚠️ Not inside any hidden element: Chrome won't resolve
   `url(#gradient)` from a `display:none` subtree, and the strokes just disappear. (A dry run that appended it near the end
   of `<body>` landed inside Framer's hidden `__framer-editorbar` div and failed exactly this way.)
3. **Existing scribbles**: add `hero/hero-scribbles.css` (or merge into `public/hero-animation.css`) and
   **remove** the old `stroke: #BFC8F5 !important` underline rule (the new `g-ribbon` rule replaces it).
   - **Rays** are background-image data-URIs, so they can't see page `#ids`. In `src/framer/Ximws3R4.js`,
     for each of the 3 `svg:` strings: add a `<defs>` holding a copy of the `g-sky` gradient and the `grain`
     filter (from `scribble-defs.svg.html`; rename ids to e.g. `rg`/`rn` to avoid clashes), set the path's
     `stroke="url(#rg)"` and `filter="url(#rn)"`. Keep the data-URI encoding (`%22` for quotes, `%23` for `#`).
     Keep the 200ms variant cycle untouched.
   - If the stem/flower paths carry inline `stroke=` attributes that win over CSS, the `!important` rules handle it;
     if not, set `stroke="url(#g-…)"` directly in `N7n53oxvv.js`.
4. **Extras**: mount `hero/hero-extras.html` inside **`.framer-8ohpt5`** (the hero's parent), *not* inside
   `.framer-wmjcqf`: the hero clips its overflow and cuts off the edge pieces. A small React component in `src/` is cleanest.
   Run the code in `hero/hero-extras-boil.js` after mount (clean up the interval/listeners on unmount). It does two things:
   pins the zero-size `.hero-extras` anchor to the centre of `h1.hero-title` (re-measured on resize, font load and h1 resize),
   and boils the stars. Offsets `--dx/--dy` are px from the headline centre at 1440px wide (scaled below 1440, hidden below 1200).
   Verified in a dry run on a copy of `public/index.html`: anchor lands exactly on the headline centre and all 7 pieces render
   unclipped, matching `reference/screenshots/hero-light-a.png`.
5. **Cards**: copy `assets/figma-projects/**` into `public/figma-projects/` (same sub-paths), then append
   `cards/cards-gradients.css` to `public/hero-animation.css`. Paths in it are root-absolute (`/figma-projects/...`).
6. **Build**: `npm ci && npm run build` (re-bundles `public/hero-animation.js` and updates the `?v=` hashes in
   `public/index.html`). If you edit `public/hero-animation.css` by hand, re-run the build so its `?v=` updates.
7. **Run**: `npm start` → http://localhost:3000.

## Verified in a dry run (copy of `public/`, local server)

- Defs as first `<body>` child + `hero-scribbles.css` + extras in `.framer-8ohpt5`: stem, flower, centre circle and underline pick up
  their gradients + grain; extras anchor to the headline and render unclipped. Rays stay flat until step 3's `Ximws3R4.js` edit.
- `cards-gradients.css` appended to `public/hero-animation.css` + assets copied: both panel backgrounds load, no 404s
  (except `/_vercel/insights/script.js`, which only exists on Vercel).
- Not verifiable offline: Framer's own runtime (loads from framerusercontent.com) and the rays edit. Check those in the real run.

## Acceptance checks

- Hero at 1440×900 matches `reference/screenshots/hero-light-a.png`: gradient + grain strokes, 7 extras evenly placed,
  none overlapping the headline, rays, stem/flower or underline; flower grain visibly softer.
- Extras draw on once, never float; the 3 stars visibly boil every 200ms in step with the rays; dots stay still.
- With `prefers-reduced-motion: reduce`: no draw-on, no boil, everything visible.
- Under 1200px: no extras; existing scribbles still render with gradients.
- FindMyLab and Cattlelog panels match `reference/screenshots/findmylab-panel.png` / `cattlelog-panel.png`, and
  hovering each still plays its full animation; no console errors; no 404s for the new `.webp` files.
- `git diff` touches only: the defs insertion, `src/framer/Ximws3R4.js` (rays), optional `N7n53oxvv.js`,
  `public/hero-animation.css`, the new extras component + its mount line, `public/figma-projects/**` (new files),
  and the build outputs.

## Regenerating gradients (optional)

```
pip install numpy scipy pillow
python3 tools/mesh.py 2200 1136 out.png '<json params>'     # params: see tools/variants.json / cl_twilight.json
```
Each entry sets colour-point positions (`pts`), flow angle, stretch, silk, light angle and `hexes`.
The look recreates Backgrounds Supply's Gradient Lab "Flow Mesh" (a Pro mode) settings Morris picked.

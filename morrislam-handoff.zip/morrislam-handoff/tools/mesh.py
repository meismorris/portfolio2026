import numpy as np, sys
from PIL import Image
import json
W,H=int(sys.argv[1]),int(sys.argv[2]); out=sys.argv[3]; P=json.loads(sys.argv[4]) if len(sys.argv)>4 else {}
rng=np.random.default_rng(5)
def srgb2lin(c): return np.where(c<=0.04045,c/12.92,((c+0.055)/1.055)**2.4)
def lin2srgb(c): return np.where(c<=0.0031308,12.92*c,1.055*np.clip(c,0,None)**(1/2.4)-0.055)
def to_oklab(rgb):
    r,g,b=srgb2lin(rgb).T
    l=np.cbrt(0.4122214708*r+0.5363325363*g+0.0514459929*b); m=np.cbrt(0.2119034982*r+0.6806995451*g+0.1073969566*b); s=np.cbrt(0.0883024619*r+0.2817188376*g+0.6299787005*b)
    return np.stack([0.2104542553*l+0.7936177850*m-0.0040720468*s,1.9779984951*l-2.4285922050*m+0.4505937099*s,0.0259040371*l+0.7827717662*m-0.8086757660*s],-1)
def from_oklab(lab):
    L,a,b=lab[...,0],lab[...,1],lab[...,2]
    l=(L+0.3963377774*a+0.2158037573*b)**3; m=(L-0.1055613458*a-0.0638541728*b)**3; s=(L-0.0894841775*a-1.2914855480*b)**3
    rgb=np.stack([4.0767416621*l-3.3077115913*m+0.2309699292*s,-1.2684380046*l+2.6097574011*m-0.3413193965*s,-0.0041960863*l-0.7034186147*m+1.7076147010*s],-1)
    return np.clip(lin2srgb(rgb),0,1)
hexes=P.get('hexes',['#7398F4','#78B0FF','#86C2FC','#A2C3FA','#B3BCFF','#C6E2FB'])
pts=np.array(P.get('pts',[(0.10,0.22),(0.90,0.86),(0.30,0.90),(0.70,0.34),(0.97,0.08),(0.55,0.02)]))
cols=to_oklab(np.array([[int(h[i:i+2],16)/255 for i in (1,3,5)] for h in hexes]))
rad,stretch,soft,flow=P.get('rad',0.33),P.get('stretch',1.8),P.get('soft',1.0),np.deg2rad(P.get('flow',28))
warp,warpS,silk,silkS,light,shine,grain=P.get('warp',0.10),1.3,P.get('silk',0.5),P.get('silkS',1.1),np.deg2rad(P.get('light',125)),P.get('shine',0.32),0.012
y,x=np.mgrid[0:H,0:W].astype(np.float32); asp=W/H
u=x/W*asp; v=y/H
# smooth value noise for warp
def vnoise(scale,seed):
    g=np.random.default_rng(seed).random((int(scale*asp)+3,int(scale)+3))
    from scipy.ndimage import zoom
    return zoom(g,(W/(g.shape[0]-2)*1.0,H/(g.shape[1]-2)*1.0),order=3)[:W,:H].T
nx=vnoise(2*warpS,P.get('seed',11))-.5; ny=vnoise(2*warpS,P.get('seed',11)+1)-.5
u2=u+warp*nx*1.2; v2=v+warp*ny*1.2
ca,sa=np.cos(flow),np.sin(flow)
num=np.zeros((H,W,3)); den=np.zeros((H,W))
for (px,py),c in zip(pts,cols):
    dx=u2-px*asp; dy=v2-py
    a=dx*ca+dy*sa; b=-dx*sa+dy*ca
    d2=(a/stretch)**2+b**2
    w=np.exp(-d2/(rad**2)/soft)+1e-6
    num+=w[...,None]*c; den+=w
lab=num/den[...,None]
# silk: soft lit folds across the flow
ph=(-(u2)*sa+(v2)*ca)*np.pi*2*2.2*silkS+nx*3
fold=np.sin(ph)
lab[...,0]+=silk*0.022*fold
# light from 125deg + shine on the fold crests
lx,ly=np.cos(light),np.sin(light)
lab[...,0]+=0.025*((u/asp-.5)*lx+(v-.5)*ly)*-1
lab[...,0]+=shine*0.05*np.clip(fold,0,1)**6
rgb=from_oklab(lab)
rgb=np.clip(rgb+np.random.default_rng(3).normal(0,grain*2.2,(H,W,1)),0,1)
Image.fromarray((rgb*255).astype(np.uint8)).save(out,quality=92)
print('ok',out)

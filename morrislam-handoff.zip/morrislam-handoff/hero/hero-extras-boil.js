/* Anchor: pin .hero-extras to the centre of the hero headline, relative to its positioned parent. */
(function(){
  const anchor=document.querySelector('.hero-extras'), h1=document.querySelector('h1.hero-title');
  if(!anchor||!h1) return;
  const place=()=>{const host=anchor.offsetParent||anchor.parentElement, a=host.getBoundingClientRect(), r=h1.getBoundingClientRect();
    anchor.style.setProperty('--ax',(r.left+r.width/2-a.left)+'px'); anchor.style.setProperty('--ay',(r.top+r.height/2-a.top)+'px');};
  place(); addEventListener('resize',place); if(document.fonts) document.fonts.ready.then(place);
  new ResizeObserver(place).observe(h1);
})();

/* Star boil: 3 jittered frames swapped every 200ms with no transition, the same rhythm as the
   rays' Framer component (Ximws3R4.js cycles Variant 1→2→3 every 200ms). On the live site the rays
   already boil, so this only drives the stars. */
(function(){
  if(matchMedia('(prefers-reduced-motion: reduce)').matches) return;
  let seed=7; const rnd=()=>{seed=(seed*16807)%2147483647;return seed/2147483647};
  const jitter=(d,amt)=>d.replace(/-?\d*\.?\d+/g,n=>(+n+(rnd()-.5)*2*amt).toFixed(2));
  const stars=[...document.querySelectorAll('.hero-extra--star svg path')];
  stars.forEach(p=>{const d=p.getAttribute('d');p._f=[d,jitter(d,3.6),jitter(d,3.6)];});
  let i=0;
  setInterval(()=>{i=(i+1)%3;stars.forEach(p=>{ if(p._f) p.setAttribute('d',p._f[i]); });
  },200);
})();

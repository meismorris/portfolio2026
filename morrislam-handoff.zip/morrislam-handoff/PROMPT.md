Paste this into Claude Code from the root of your `portfolio2026` repo, after unzipping this
folder somewhere it can read (e.g. `~/Downloads/morrislam-handoff`):

---

I have a design handoff for this site in `~/Downloads/morrislam-handoff`. Read
`~/Downloads/morrislam-handoff/HANDOFF.md` first and follow it: apply the hero scribble gradients/grain,
add the Light A hero extras with the star boil, and apply the FindMyLab (Drift) and Cattlelog (Twilight)
panel backgrounds, using the snippets and assets in that folder. Work on a new branch, keep the existing
GSAP hover animations working, run `npm run build`, start the site, and check it against the screenshots in
`reference/screenshots/` and the acceptance checks in HANDOFF.md. Don't push or deploy. Show me the diff and
anything you had to calibrate (like the extras offset) when you're done.

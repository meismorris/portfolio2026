# Selected Projects: add Trailhead + Surf cards, 2×2 desktop grid

For the `meismorris/portfolio2026` repo. FindMyLab and Cattlelog already exist and are **not**
changed here. This adds two cards below them and lays the four out as a 2×2 grid on desktop.

**Work on a new branch. Don't push or deploy without asking Morris.**

Verified: applied to a clean copy of the repo, `npm run build`, served `public/`. All four cards
render in the grid, hovers work, no console errors, no 404s (except `/_vercel/insights/script.js`,
which only exists on Vercel).

## What's in this folder

```
src/TrailheadPanel.jsx          new card component
src/SurfiPanel.jsx              new card component
src/SelectedProjects.diff       2 imports + 2 rows (git apply it, or copy by hand)
css/new-cards.css               append to public/hero-animation.css (3 blocks, see below)
public/figma-projects/trail-panel/   mesh-meadow.webp, hike-map.webp, hike-drawer.webp, photo-redwood.webp
public/figma-projects/surfi-panel/   mesh-dusk.webp, surf-logo.svg
public/fonts/general-sans/      GeneralSans-Regular.otf, GeneralSans-Medium.otf (Trailhead widgets)
reference/screenshots/          grid-2x2.png, trailhead-rest.png, trailhead-hover.png/.gif, surf-hover.gif
```

## Steps

1. `git checkout -b trailhead-surf-grid`
2. Copy `src/*.jsx` into `src/`, then `git apply src/SelectedProjects.diff` (adds the imports and
   two `selected-projects__row--panel` rows after Cattlelog: Trailhead, then Surf).
3. Copy `public/**` into the repo's `public/` (same sub-paths).
4. Append `css/new-cards.css` to the end of `public/hero-animation.css`.
5. `npm run build` (re-bundles `public/hero-animation.js`, updates the `?v=` hashes in `public/index.html`).
6. `npm start` and check against `reference/screenshots/`.

## How the cards work

Both reuse the FindMyLab card shell (`fml-panel` / `fml-panel__card` / `__banner` / `__caption`),
so they size from their own width via `--u` (container units) exactly like FindMyLab.
Neither is a link yet (no case-study pages); both are `role="group"` with an aria-label.

**Trailhead** (`.trail-panel`)
- Background: meadow flow-mesh image `mesh-meadow.webp`.
- Phone: `hike-map.webp` (the prototype's "On the trail" map) with `hike-drawer.webp` on top.
  At rest the drawer sits at the prototype's peek position; on hover it slides up to full hike details
  (`transform` on `.trail-panel__drawer`, 0.7s, iOS-style ease).
- Widgets: two pills (Works offline, Signal drops 0.4 mi in), a trail card with the redwood photo,
  a hike-plan timeline card. On hover they drift slightly outward.
- Trees: a hill + 4 trees per side (`.trail-panel__corner--l/--r`) slide in from the left and right
  edges on hover, trees pop up one after another with a springy overshoot.
- Reduced motion: no transitions; drawer/trees just change state.

**Surf** (`.surfi-panel`)
- Background: dusk flow-mesh `mesh-dusk.webp` (navy #141922 → pink #AA7094), centered white Surf logo
  (`surf-logo.svg`, traced from a screenshot; swap in the official file if Morris has it).
- Hover: the gradient pans/zooms slightly and a soft pink/mauve glow fades in and drifts.
- Reduced motion: glow fades in only.

**2×2 grid** (last block of `new-cards.css`, `@media (min-width: 1001px)`)
- `.selected-projects__list` becomes a 2-column grid (gap 40px/32px, full column width, overriding the
  85% width rule at ≥721px).
- Captions get fixed sizes in the grid (title 20px, subtitle 16px).
- The FindMyLab/Cattlelog stats stay **horizontal** in the grid: the cards' own `@container (max-width:640px)`
  rule would stack them at half width, so the grid block restores the row layout and scaled type
  (~14.5px at 1440). ≤1000px: single column, original behaviour (stats stack on narrow cards).

## Placeholders to confirm with Morris

- Trailhead subtitle "a hiking app that keeps working when the signal drops" and year 2026.
- Surf caption reads "Surfi AI • 2026 / work in progress" while the logo says "Surf". Confirm the name.
- Widget content is the prototype's sample data.

## Acceptance checks

- At 1440×900: four cards in a 2×2 grid, FindMyLab + Cattlelog on top with stats in one row.
- Trailhead hover: drawer slides up, trees slide in from both sides, widgets drift out; reverses on leave.
- Surf hover: gradient shifts, pink glow appears.
- At ≤1000px: one card per row.
- No console errors, no 404s for the new assets.
- `git diff` touches only: `src/SelectedProjects.jsx`, the two new components, `public/hero-animation.css`,
  the new files under `public/`, and the build outputs.

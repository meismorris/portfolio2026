Unzip this folder somewhere Claude Code can read (e.g. `~/Downloads/cards-handoff`), open Claude Code in
your `portfolio2026` repo, and paste:

---

I have a handoff in `~/Downloads/cards-handoff`. Read `~/Downloads/cards-handoff/HANDOFF.md` and follow it:
add the Trailhead and Surf cards below FindMyLab and Cattlelog and make Selected Projects a 2×2 grid on
desktop, using the components, CSS and assets in that folder. Don't change the FindMyLab or Cattlelog cards.
Work on a new branch, run `npm run build`, start the site, and check it against `reference/screenshots/`
and the acceptance checks. Don't push or deploy. Show me the diff when you're done.
